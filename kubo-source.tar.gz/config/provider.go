package config

type Provider struct {
	Strategy string // Which keys to announce
}
