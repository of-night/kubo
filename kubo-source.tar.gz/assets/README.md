# Assets loaded in with IPFS

This directory contains the go-ipfs assets:

* Getting started documentation (`init-doc`).
