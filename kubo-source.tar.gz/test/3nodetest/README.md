this is an ipfs integration test

**requirements**

* Docker
* fig
* Go

* ipfs image named "zaqwsx_ipfs-test-img"

```
make setup
fig build 
fig up
```
